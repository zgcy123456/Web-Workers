TRUNCATE TABLE `user`;
INSERT INTO `user` VALUES ('1', 'admin', 'admin');