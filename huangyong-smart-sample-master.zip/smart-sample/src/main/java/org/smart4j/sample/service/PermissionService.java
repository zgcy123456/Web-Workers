package org.smart4j.sample.service;

import java.util.List;
import org.smart4j.sample.entity.Permission;

public interface PermissionService {

    List<Permission> getPermissionList();
}
