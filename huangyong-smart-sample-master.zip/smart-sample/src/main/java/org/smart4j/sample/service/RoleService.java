package org.smart4j.sample.service;

import java.util.List;
import org.smart4j.sample.entity.Role;

public interface RoleService {

    List<Role> getRoleList();
}
